function [A] = assemb_A(K,mesh)
% A=ASSEMB_A(K,mesh) assemble et retourne la matrice de rigidite EF P1 de Lagrange 
% c'est a dire la matrice EF associe a l'operateur -grad (K grad U)
% sur le maillage mesh ou mesh est une structure contenant les champs 
% nbs,nbt,elm_som,som_coo,som_zon
%
% Ne tient pas compte des Conditions aux Limites
% K est suppose constant par element et transmis sous forme de tableau
% colonne à mesh.nbt lignes
%