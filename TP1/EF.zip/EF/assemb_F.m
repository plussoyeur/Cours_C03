function [F] = assemb_F(fun,mesh)
% F=ASSEMB_F(fun,mesh) assemble le second membre du pb du Laplacien
% avec conditions aux limites de Neumann Homogenes
% c'est-a-dire F_i = \int_{\Omega} fun(x,y)*\phi_i dxdy 
% pour la methode des EF P1 de Lagrange
%
% La fonction fun(x,y) est une fonction de 2 arguments 
%